import React, { useRef, useState } from 'react';
import { supabase, logActivity } from '../supabase';
import { 
  Database, 
  Upload, 
  Download, 
  FileSpreadsheet, 
  Trash2, 
  Loader2,
} from 'lucide-react';
import { useAuth, cn } from '../App';
import { motion } from 'motion/react';

const BATCH_SIZE = 500;  // 500 rows/batch — reliable with PostgREST payload limits

export function MastersModule() {
  const { profile, user, activeAssignment } = useAuth(); 
  const assignmentId = activeAssignment?.id || 'assignment-1'; 
  
  const [isUploadingItem, setIsUploadingItem] = useState(false);
  const [itemProgress, setItemProgress] = useState({ current: 0, total: 0 });
  const [isUploadingSales, setIsUploadingSales] = useState(false);
  const [salesProgress, setSalesProgress] = useState({ current: 0, total: 0 });

  const [isClearingSales, setIsClearingSales] = useState(false);
  const [isClearingItems, setIsClearingItems] = useState(false);
  
  const itemFileRef = useRef<HTMLInputElement>(null);
  const salesFileRef = useRef<HTMLInputElement>(null);

  const downloadItemTemplate = () => {
    const csv = "ItemCode,ItemName,GST,Category,ApproxShelfLife,StandardPack\nITM-001,Premium Shampoo 500ml,18,Personal Care,24 Months,12";
    triggerDownload(csv, "Item_Master_Template.csv");
  };

  const downloadSalesTemplate = () => {
    const csv = "BillingDate,SoldToParty,MaterialNo,ItemName,Plant,BillingDoc,Category,TotalValue,TotalQty,GST,ApproxShelfLife,StandardPack\n2023-10-01,DIST-001,ITM-001,Premium Shampoo,PLNT1,INV-1001,Personal Care,37575.00,150,18,24 Months,12";
    triggerDownload(csv, "Sales_Dump_Template.csv");
  };

  const triggerDownload = (content: string, filename: string) => {
    const blob = new Blob([content], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a'); link.href = URL.createObjectURL(blob); link.download = filename; link.click();
  };

  // ── PROPER CSV LINE PARSER ─────────────────────────────────────────────────
  // Handles quoted fields that contain commas (e.g. " 472,145.17 ")
  // Standard line.split(',') breaks on the comma inside quotes — this does not.
  const parseCSVLine = (line: string): string[] => {
    const result: string[] = [];
    let current = '';
    let inQuotes = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (ch === '"') {
        inQuotes = !inQuotes;
      } else if (ch === ',' && !inQuotes) {
        result.push(current.trim().replace(/\r/g, ''));
        current = '';
      } else {
        current += ch;
      }
    }
    result.push(current.trim().replace(/\r/g, ''));
    return result;
  };

  // ── SMART HEADER COLUMN LOOKUP ─────────────────────────────────────────────
  const getColValue = (headers: string[], rowVals: string[], possibleNames: string[]) => {
    for (const name of possibleNames) {
      const idx = headers.findIndex(
        h => h.toLowerCase() === name.toLowerCase() ||
             h.toLowerCase().replace(/\s/g, '') === name.toLowerCase().replace(/\s/g, '')
      );
      if (idx !== -1) return rowVals[idx]?.trim() || '';
    }
    return '';
  };

  // ── SAFE NUMBER PARSERS ────────────────────────────────────────────────────
  // Strips commas, spaces, %, currency symbols before parsing
  // e.g. " 472,145.17 " → 472145.17 | "40%" → 40
  const parseNum  = (s: string) => parseFloat(s.replace(/[^0-9.]/g, '')) || 0;
  const parseInt2 = (s: string) => parseInt(s.replace(/[^0-9]/g, ''), 10) || 0;

  // ── ITEM MASTER UPLOAD ─────────────────────────────────────────────────────
  const handleItemMasterUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user || !profile) return;

    setIsUploadingItem(true); setItemProgress({ current: 0, total: 0 });
    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const text = event.target?.result as string;
        const lines = text.split('\n').filter(line => line.trim() !== '');
        if (lines.length < 2) throw new Error("File is empty or missing headers");

        const headers = parseCSVLine(lines[0]).map(h => h.replace(/['"]/g, ''));
        
        const rawItems = lines.slice(1).map(line => {
          const cols = parseCSVLine(line);
          
          const itemCode = getColValue(headers, cols, ['ItemCode', 'MaterialNo']);
          const itemName = getColValue(headers, cols, ['ItemName', 'Description']);
          const gst = getColValue(headers, cols, ['GST']);
          const category = getColValue(headers, cols, ['Category']);
          const approxShelfLife = getColValue(headers, cols, ['ApproxShelfLife', 'ShelfLife']);
          const standardPack = getColValue(headers, cols, ['StandardPack']);

          if (!itemCode || !itemName) return null;
          
          return { 
            id: crypto.randomUUID(), 
            assignment_id: assignmentId,
            itemCode, 
            itemName, 
            gst: parseNum(gst), 
            category: category || 'Uncategorized', 
            approxShelfLife: approxShelfLife || 'N/A', 
            standardPack: standardPack || 'N/A' 
          };
        }).filter(Boolean);

        if (rawItems.length === 0) throw new Error("No valid data found in CSV.");

        // Deduplicate by itemCode
        const uniqueDataMap = new Map();
        rawItems.forEach((item: any) => uniqueDataMap.set(item.itemCode, item));
        const items = Array.from(uniqueDataMap.values());
        const duplicatesRemoved = rawItems.length - items.length;

        setItemProgress({ current: 0, total: items.length });

        let processed = 0;
        for (let i = 0; i < items.length; i += BATCH_SIZE) {
          const batch = items.slice(i, i + BATCH_SIZE);
          const { error } = await supabase.from('itemMaster').upsert(batch, { onConflict: 'assignment_id,itemCode' });
          if (error) throw error;
          processed += batch.length; setItemProgress({ current: processed, total: items.length });
        }
        
        logActivity(user, profile, "Master Data Uploaded", `Uploaded/Updated ${items.length} items in the Item Master.`, assignmentId);
        alert(`Success! ${items.length} items uploaded to the Master.\n${duplicatesRemoved > 0 ? `(Skipped ${duplicatesRemoved} duplicate entries found in your file)` : ''}`);
      } catch (error: any) { alert(`Upload failed: ${error.message || 'Invalid CSV format'}`); } 
      finally { setIsUploadingItem(false); setItemProgress({ current: 0, total: 0 }); if (itemFileRef.current) itemFileRef.current.value = ''; }
    };
    reader.readAsText(file);
  };

  // ── SALES DUMP UPLOAD ──────────────────────────────────────────────────────
  const handleSalesDumpUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file || !user || !profile) return;

    setIsUploadingSales(true); setSalesProgress({ current: 0, total: 0 });
    const reader = new FileReader();
    reader.onload = async (event) => {
      try {
        const text = event.target?.result as string;
        const lines = text.split('\n').filter(line => line.trim() !== '');
        if (lines.length < 2) throw new Error("File is empty or missing headers");

        // Use proper CSV parser for headers too
        const headers = parseCSVLine(lines[0]).map(h => h.replace(/['"]/g, ''));
        
        // ── Parse all rows from CSV ────────────────────────────────────────
        const rawItems = lines.slice(1).map(line => {
          const cols = parseCSVLine(line);

          const soldToParty = getColValue(headers, cols, ['SoldToParty', 'DistributorCode']);
          const materialNo  = getColValue(headers, cols, ['MaterialNo', 'ItemCode']);
          if (!soldToParty || !materialNo) return null;

          const totalQtyStr   = getColValue(headers, cols, ['TotalQty', 'Quantity', 'Qty']);
          const totalValueStr = getColValue(headers, cols, ['TotalValue', 'Value', 'Total Value']);
          const gstStr        = getColValue(headers, cols, ['GST']);
          const billingDoc    = getColValue(headers, cols, ['BillingDoc', 'InvoiceNo']);
          const billingDate   = getColValue(headers, cols, ['BillingDate', 'Date']);

          // parseNum uses parseFloat — safe for values beyond integer max (2.1B)
          // parseInt2 was capping at JS int32 causing "out of range for type integer"
          const totalQty   = parseNum(totalQtyStr);
          const totalValue = parseNum(totalValueStr);
          const rate       = totalQty > 0 ? totalValue / totalQty : 0;

          // ── No client-side id — let Supabase auto-generate it via DEFAULT ─
          // This completely avoids salesDump_pkey collisions because the DB
          // assigns the id, guaranteeing uniqueness regardless of CSV content.
          // Clamp quantity fields: Postgres `integer` max = 2,147,483,647.
          // If qty > 2B it overflows — store as numeric string or cap.
          // Best fix: ALTER TABLE salesDump ALTER COLUMN quantity TYPE bigint;
          // Meanwhile, we send as a JS number (PostgREST accepts numeric).
          const safeQty = Math.round(totalQty);   // whole units, no decimals

          // Send id explicitly — DB column has no DEFAULT gen_random_uuid() yet.
          // crypto.randomUUID() = 128-bit UUID, zero collision risk at 75k rows.
          return {
            id:              crypto.randomUUID(),
            assignment_id:   assignmentId,
            distributorCode: soldToParty,
            itemCode:        materialNo,
            quantity:        safeQty,
            rate,
            billingDate,
            soldToParty,
            materialNo,
            plant:           getColValue(headers, cols, ['Plant']),
            billingDoc,
            category:        getColValue(headers, cols, ['Category']),
            totalValue,
            totalQty:        safeQty,
            itemName:        getColValue(headers, cols, ['ItemName', 'Description']),
            gst:             parseNum(gstStr),
            approxShelfLife: getColValue(headers, cols, ['ApproxShelfLife', 'ShelfLife']),
            standardPack:    getColValue(headers, cols, ['StandardPack']),
          };
        }).filter(Boolean);

        if (rawItems.length === 0) throw new Error("No valid data found in CSV.");

        const dumpItems = rawItems;
        const dupsRemoved = 0;

        setSalesProgress({ current: 0, total: dumpItems.length });

        // ── Parallel batch insert — 5 batches fired simultaneously ──────────
        // No row-level fallback (that was causing 2000 HTTP requests per failed
        // batch = 10+ minutes). If a batch fails we log and skip the whole
        // batch, then continue — never block the rest of the upload.
        const PARALLEL = 5;
        let processed  = 0;
        let errorCount = 0;

        // Split all items into batches upfront
        const batches: any[][] = [];
        for (let i = 0; i < dumpItems.length; i += BATCH_SIZE) {
          batches.push(dumpItems.slice(i, i + BATCH_SIZE));
        }

        // Process PARALLEL batches at a time
        for (let i = 0; i < batches.length; i += PARALLEL) {
          const group = batches.slice(i, i + PARALLEL);
          const results = await Promise.all(
            group.map(batch => supabase.from('salesDump').upsert(batch, { onConflict: 'id', ignoreDuplicates: true }))
          );
          for (let j = 0; j < results.length; j++) {
            if (results[j].error) {
              console.warn('Batch failed, skipping:', results[j].error.message);
              errorCount += group[j].length;
            } else {
              processed += group[j].length;
            }
          }
          setSalesProgress({ current: processed + errorCount, total: dumpItems.length });
        }

        logActivity(user, profile, "Sales Dump Uploaded",
          `Uploaded ${processed} records. ${dupsRemoved > 0 ? `Deduped ${dupsRemoved} CSV duplicates. ` : ''}${errorCount > 0 ? `Skipped ${errorCount} problem rows.` : ''}`);
        alert(
          `Upload complete!\n\n` +
          `✅ Inserted: ${processed.toLocaleString()} records\n` +
          (dupsRemoved > 0 ? `⚠️ CSV duplicates removed: ${dupsRemoved.toLocaleString()}\n` : '') +
          (errorCount  > 0 ? `❌ Skipped rows (DB error): ${errorCount}\n` : '')
        );
      } catch (error: any) { alert(`Upload failed: ${error.message || 'Invalid CSV format'}`); } 
      finally { setIsUploadingSales(false); setSalesProgress({ current: 0, total: 0 }); if (salesFileRef.current) salesFileRef.current.value = ''; }
    };
    reader.readAsText(file);
  };

  const clearSalesDump = async () => {
    if (!user || !profile) return;
    if (profile.role !== 'superadmin') return alert("Action Denied: Only SuperAdmins can delete database contents.");
    if (window.confirm(`WARNING: This will permanently delete ALL data in the Sales Dump for "${activeAssignment?.name || 'this assignment'}". Do you want to continue?`)) {
      setIsClearingSales(true);
      try {
        const { error } = await supabase.from('salesDump').delete().eq('assignment_id', assignmentId).neq('id', '0');
        if (error) throw error; 
        logActivity(user, profile, "Sales Dump Cleared", `WARNING: Action executed. Sales Dump for ${activeAssignment?.name} was wiped.`, assignmentId);
        alert("Sales Dump for this assignment has been completely cleared.");
      } catch (error) { alert("Failed to clear Sales Dump."); } 
      finally { setIsClearingSales(false); }
    }
  };

  const clearItemMaster = async () => {
    if (!user || !profile) return;
    if (profile.role !== 'superadmin') return alert("Action Denied: Only SuperAdmins can delete database contents.");
    if (window.confirm(`WARNING: This will permanently delete ALL products in the Item Master for "${activeAssignment?.name || 'this assignment'}". Do you want to continue?`)) {
      setIsClearingItems(true);
      try {
        const { error } = await supabase.from('itemMaster').delete().eq('assignment_id', assignmentId).neq('id', '0');
        if (error) throw error; 
        logActivity(user, profile, "Item Master Cleared", `WARNING: Action executed. Item Master for ${activeAssignment?.name} was wiped.`, assignmentId);
        alert("Item Master for this assignment has been completely cleared.");
      } catch (error) { alert("Failed to clear Item Master."); } 
      finally { setIsClearingItems(false); }
    }
  };

  if (!['superadmin', 'admin', 'ho'].includes(profile?.role || '')) return <div className="p-8 text-center text-red-500 font-bold">Access Denied. Admins & HO only.</div>;

  return (
    <div className="space-y-8 pb-12">
      <div className="mb-8">
        <h2 className="text-2xl font-bold tracking-tight mb-2 flex items-center gap-2"><Database className="text-black" /> Master Data Management</h2>
        <p className="text-zinc-500">Upload and manage the central data repositories that power the Execution audits.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        
        {/* ITEM MASTER CARD */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="bg-white rounded-[2.5rem] border border-zinc-200 shadow-sm p-8 flex flex-col h-full relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-2 bg-blue-500" />
          <div className="flex items-center gap-4 mb-6">
            <div className="w-14 h-14 bg-blue-50 rounded-2xl flex items-center justify-center shrink-0"><FileSpreadsheet className="text-blue-600" size={24} /></div>
            <div><h3 className="text-xl font-bold">Item Master</h3><p className="text-xs font-bold uppercase tracking-wider text-zinc-400 mt-1">Global Product Catalog</p></div>
          </div>
          <div className="flex-1 space-y-4 mb-8 text-sm text-zinc-600">
            <div className="p-4 bg-zinc-50 rounded-xl border border-zinc-100"><p className="font-bold text-zinc-900 mb-2 text-xs uppercase">Required Columns:</p><code className="text-xs text-blue-600">ItemCode, ItemName, GST, Category, ApproxShelfLife, StandardPack</code></div>
          </div>
          <div className="space-y-3 mt-auto">
            <div className={cn("grid gap-3", profile?.role === 'superadmin' ? "grid-cols-2" : "grid-cols-1")}>
              <button onClick={downloadItemTemplate} disabled={isUploadingItem} className="w-full py-3 bg-zinc-100 hover:bg-zinc-200 text-zinc-900 rounded-xl font-bold text-sm transition-colors flex items-center justify-center gap-2 disabled:opacity-50"><Download size={16} /> Template</button>
              {profile?.role === 'superadmin' && (
                <button onClick={clearItemMaster} disabled={isClearingItems || isUploadingItem} className="w-full py-3 bg-red-50 hover:bg-red-100 text-red-700 rounded-xl font-bold text-sm transition-colors flex items-center justify-center gap-2 disabled:opacity-50">{isClearingItems ? <Loader2 className="animate-spin" size={16} /> : <Trash2 size={16} />} Clear Master</button>
              )}
            </div>
            <input type="file" accept=".csv" ref={itemFileRef} onChange={handleItemMasterUpload} className="hidden" />
            <button onClick={() => itemFileRef.current?.click()} disabled={isUploadingItem} className="w-full py-4 bg-black text-white rounded-xl font-bold hover:bg-zinc-800 transition-all shadow-lg shadow-black/10 flex items-center justify-center gap-2 disabled:opacity-90 relative overflow-hidden">
              {isUploadingItem ? (<div className="flex flex-col items-center gap-1 z-10 relative"><span className="flex items-center gap-2"><Loader2 className="animate-spin" size={18} /> Processing Batches...</span><span className="text-[10px] text-zinc-300 font-mono tracking-wider">{itemProgress.current.toLocaleString()} / {itemProgress.total.toLocaleString()} Rows</span></div>) : (<><Upload size={18} /> Upload Item Master CSV</>)}
              {isUploadingItem && (<div className="absolute left-0 bottom-0 h-1 bg-blue-500 transition-all duration-300" style={{ width: `${(itemProgress.current / itemProgress.total) * 100}%` }} />)}
            </button>
          </div>
        </motion.div>

        {/* SALES DUMP CARD */}
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }} className="bg-white rounded-[2.5rem] border border-zinc-200 shadow-sm p-8 flex flex-col h-full relative overflow-hidden">
          <div className="absolute top-0 left-0 w-full h-2 bg-emerald-500" />
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-4">
              <div className="w-14 h-14 bg-emerald-50 rounded-2xl flex items-center justify-center shrink-0"><Database className="text-emerald-600" size={24} /></div>
              <div><h3 className="text-xl font-bold">Sales Dump</h3><p className="text-xs font-bold uppercase tracking-wider text-zinc-400 mt-1">Distributor Inventory Mapping</p></div>
            </div>
          </div>
          <div className="flex-1 space-y-4 mb-8 text-sm text-zinc-600">
            <div className="p-4 bg-zinc-50 rounded-xl border border-zinc-100">
              <p className="font-bold text-zinc-900 mb-2 text-xs uppercase">Required Columns:</p>
              <code className="text-[10px] sm:text-[11px] text-emerald-600 leading-relaxed block break-words">BillingDate, SoldToParty, MaterialNo, ItemName, Plant, BillingDoc, Category, TotalValue, TotalQty, GST, ApproxShelfLife, StandardPack</code>
            </div>
          </div>
          <div className="space-y-3 mt-auto">
            <div className={cn("grid gap-3", profile?.role === 'superadmin' ? "grid-cols-2" : "grid-cols-1")}>
              <button onClick={downloadSalesTemplate} disabled={isUploadingSales} className="w-full py-3 bg-zinc-100 hover:bg-zinc-200 text-zinc-900 rounded-xl font-bold text-sm transition-colors flex items-center justify-center gap-2 disabled:opacity-50"><Download size={16} /> Template</button>
              {profile?.role === 'superadmin' && (
                <button onClick={clearSalesDump} disabled={isClearingSales || isUploadingSales} className="w-full py-3 bg-red-50 hover:bg-red-100 text-red-700 rounded-xl font-bold text-sm transition-colors flex items-center justify-center gap-2 disabled:opacity-50">{isClearingSales ? <Loader2 className="animate-spin" size={16} /> : <Trash2 size={16} />} Clear Dump</button>
              )}
            </div>
            <input type="file" accept=".csv" ref={salesFileRef} onChange={handleSalesDumpUpload} className="hidden" />
            <button onClick={() => salesFileRef.current?.click()} disabled={isUploadingSales} className="w-full py-4 bg-black text-white rounded-xl font-bold hover:bg-zinc-800 transition-all shadow-lg shadow-black/10 flex items-center justify-center gap-2 disabled:opacity-90 relative overflow-hidden">
              {isUploadingSales ? (<div className="flex flex-col items-center gap-1 z-10 relative"><span className="flex items-center gap-2"><Loader2 className="animate-spin" size={18} /> Processing Batches...</span><span className="text-[10px] text-zinc-300 font-mono tracking-wider">{salesProgress.current.toLocaleString()} / {salesProgress.total.toLocaleString()} Rows</span></div>) : (<><Upload size={18} /> Append to Sales Dump</>)}
              {isUploadingSales && (<div className="absolute left-0 bottom-0 h-1 bg-emerald-500 transition-all duration-300" style={{ width: `${(salesProgress.current / salesProgress.total) * 100}%` }} />)}
            </button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}